---
title: Install Chinese Patch
category: firstguide
layout: post
---

This page is not available in English.
