---
title: Change Log (This Website)
author: 夜輪風超絶技巧変奏曲
date: 2022-11-16
category: Change Log
layout: post
---

## 2022.11.16

- Material for MkDocs is updated to 8.5.10.
    - `Successfully installed jinja2-3.1.2 mkdocs-material-8.5.10 mkdocs-material-extensions-1.1 requests-2.28.1`
    - Style change of annotation took place in version 8.5.6.
- Each page will now display the date it was created at the bottom of it.
    - Applied the following setting to git-revision-date-localized plugin: `enable_creation_date: true`.

## 2022.6.7

The first version.
