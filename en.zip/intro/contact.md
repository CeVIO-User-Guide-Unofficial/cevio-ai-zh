---
title: Contact
category: Basic Info
layout: post
---

If you have any questions, comments or suggestions about this project, please create a new topic in [Discussions](https://github.com/CeVIO-User-Guide-Unofficial/CeVIO-AI/discussions).

You can report any problems in [Issues](https://github.com/CeVIO-User-Guide-Unofficial/CeVIO-AI/issues/new).

For further contact, please send an email to [nachtgeistw@protonmail.com](mailto:nachtgeistw@protonmail.com).
